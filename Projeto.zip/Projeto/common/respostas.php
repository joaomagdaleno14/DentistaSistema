<?php

const SUCESSO = 1;
const FALHA = 0;