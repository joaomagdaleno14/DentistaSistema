<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sistema de Consultas</title>
    <link rel="stylesheet" href="Style.css">
</head>

<body>
    
    <div class="sidenav">
        <a href="view/cadastropaciente.php">Cadastro Pacientes</a>
        <a href="view/matutencaoconsulta.php">Cadastro Consultas</a>
        <a href="view/selecaopaciente.php">Listar Paciente</a>
        <a href="view/selecaoconsulta.php">Listar Consulta</a>
    </div>

    <div class="Content">
    </div>

    </body>
</html>

