<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sistema de Consultas</title>
    <link rel="stylesheet" href="Style.css">
</head>

<body>
    
    <div class="sidenav">
        <a href="cadastropaciente.php">Cadastro Pacientes</a>
        <a href="matutencaoconsulta.php">Cadastro Consultas</a>
        <a href="selecaopaciente.php">Listar Paciente</a>
        <a href="selecaoconsulta.php">Listar Consulta</a>
    </div>
